import React, { useEffect, useState } from 'react';
import { Phone, MessageCircle, Globe, Menu, X, ArrowLeft, ArrowRight, Building2, Container, Factory, HardHat, Layers, CheckCircle2, MapPin, Clock, ChevronDown, Home, Landmark, Sparkles, Truck, Crown, ShieldCheck, Ruler, Star, BadgeCheck, ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import mosqueImg from 'container:///mnt/data/src/assets/3a4a3e893d62c626-image_20261111_141257.webp';
import villaImg from 'container:///mnt/data/src/assets/22bc4dd1b78a8cb5-image_20261111_141258.webp';
import interiorImg from 'container:///mnt/data/src/assets/f7195d2e8f426e2f-image_20261111_141258_1.webp';
import factoryImg from 'container:///mnt/data/src/assets/88efd95160ea5100-image_20261111_141259.webp';
import majlisImg from 'container:///mnt/data/src/assets/ccc5cb1576a9c11d-image_20261111_144100.webp';
import containerImg from 'container:///mnt/data/src/assets/baa6db9fa3594555-image_20261111_144107.webp';
import steelImg from 'container:///mnt/data/src/assets/94d04d587ef4706e-image_20261111_144103.webp';

type Lang = 'en' | 'ar';
type ServiceKey = 'prefab' | 'gfrc' | 'gfrp' | 'gfrg' | 'steel' | 'container' | 'contracting' | 'transport';

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json?.error) throw new Error(json?.error || `Request failed (${res.status})`);
  return json.data;
}

function Ornament() {
  return (
    <div className="flex items-center justify-center gap-3" aria-hidden="true">
      <span className="h-px w-12 sm:w-20 bg-gradient-to-l from-transparent to-[#C9A227]" />
      <span className="w-2.5 h-2.5 rotate-45 bg-[#C9A227]" />
      <span className="w-1.5 h-1.5 rotate-45 bg-[#0F3D2E]" />
      <span className="w-2.5 h-2.5 rotate-45 bg-[#C9A227]" />
      <span className="h-px w-12 sm:w-20 bg-gradient-to-r from-transparent to-[#C9A227]" />
    </div>
  );
}

const fmtSAR = (n: number) => `SAR ${n.toLocaleString('en-US')}`;

export default function App() {
  const [lang, setLang] = useState<Lang>('en');
  const [menu, setMenu] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [service, setService] = useState<ServiceKey>('prefab');
  const [slide, setSlide] = useState(0);
  const [paused, setPaused] = useState(false);
  const [area, setArea] = useState(320);
  const [city, setCity] = useState('Al-Rass');
  const [budget, setBudget] = useState(500000);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ saved: number; remaining: number; error: string | null; reloadError: string | null } | null>(null);
  const [savedCount, setSavedCount] = useState<number | null>(null);
  const [loadError, setLoadError] = useState('');
  const ar = lang === 'ar';
  const dirArrow = ar ? ArrowLeft : ArrowRight;

  const t = {
    home: ar ? 'الرئيسية' : 'Home', services: ar ? 'خدماتنا' : 'Services', projects: ar ? 'أعمالنا' : 'Projects', about: ar ? 'من نحن' : 'About', contact: ar ? 'تواصل' : 'Contact',
    quote: ar ? 'اطلب عرض سعر' : 'Get a Quotation', explore: ar ? 'استعرض أعمالنا' : 'Explore Our Work',
    heroBadge: ar ? 'مصنعنا • حرفتنا • فخامتك' : 'Our Factory • Our Craft • Your Luxury',
    heroTitle1: ar ? 'نصنع الفخامة..' : 'We Craft Luxury —',
    heroTitle2: ar ? 'من المصنع إلى موقعك' : 'From Factory to Site',
    heroSub: ar ? 'واجهات تليق بطموحك، وبيوت تُبنى بدقة المصنع وذوق القصور. من الرس في القصيم، نخدم جميع مناطق السعودية.' : 'Façades worthy of your ambition, and homes built with factory precision and palace taste. From Al-Rass in Al-Qassim, we serve all of Saudi Arabia.',
    heroSlideLabel: ar ? 'استعرض أعمالنا' : 'Explore Our Work',
    stats: [
      { v: '+10', l: ar ? 'سنوات من الحرفية' : 'Years of Craft' },
      { v: '95%', l: ar ? 'تسليم في الوقت' : 'On-Time Delivery' },
      { v: '3X', l: ar ? 'أسرع من البناء التقليدي' : 'Faster Building' },
      { v: '1', l: ar ? 'فرع واحد — الرس' : 'One Branch — Al-Rass' },
    ],
  };

  const slides = [
    { img: mosqueImg, tag: 'GFRC', title: ar ? 'واجهة مسجد بتفاصيل GFRC' : 'Mosque Façade — GFRC Detail', sub: ar ? 'تفاصيل ذهبية تُصنع داخل مصنعنا' : 'Golden detail, crafted inside our factory' },
    { img: villaImg, tag: ar ? 'مبانٍ جاهزة' : 'Prefab Houses', title: ar ? 'فيلا فاخرة — القصيم' : 'Luxury Villa — Al-Qassim', sub: ar ? 'واجهة GFRC • تشطيب ذهبي' : 'GFRC façade • Golden finish' },
    { img: interiorImg, tag: 'GFRG', title: ar ? 'قاعة استقبال ملكية' : 'Royal Hall — GFRG', sub: ar ? 'أعمدة GFRG • ثريا ذهبية' : 'GFRG columns • Golden chandelier' },
    { img: factoryImg, tag: 'GFRC', title: ar ? 'مصنع GFRC — حرفية دقيقة' : 'Our Factory — Precise Craft', sub: ar ? 'قوالب مخصصة • جودة مضبوطة' : 'Custom moulds • Controlled quality' },
    { img: majlisImg, tag: ar ? 'مجلس فاخر' : 'Majlis', title: ar ? 'مجلس فاخر بإضاءة ذهبية' : 'Luxury Majlis — Golden Light', sub: ar ? 'واجهات مشغولة • حضور يليق بك' : 'Ornamental façades • A presence worthy of you' },
    { img: containerImg, tag: ar ? 'تعديل حاويات' : 'Container Office', title: ar ? 'مكتب حاويات بهوية خاصة' : 'Container Office — Made Your Own', sub: ar ? 'مساحات تجارية ومكاتب بهويتك' : 'Offices & commercial spaces with your identity' },
    { img: steelImg, tag: ar ? 'هياكل فولاذية' : 'Steel Structure', title: ar ? 'فيلا بهيكل فولاذي' : 'Steel Villa — Built to Last', sub: ar ? 'تصميم إنشائي معتمد • تنفيذ آمن' : 'Certified engineering • Safe execution' },
  ];

  const services: { key: ServiceKey; ar: string; en: string; descAr: string; descEn: string; icon: any; img: string }[] = [
    { key: 'prefab', ar: 'المباني الجاهزة', en: 'Prefabricated Houses', descAr: 'فلل ووحدات سكنية ومكاتب تُصنَّع بدقة داخل المصنع وتُركَّب في موقعك بتشطيب فاخر.', descEn: 'Villas, homes and offices manufactured with precision and installed with a luxurious finish.', icon: Home, img: villaImg },
    { key: 'gfrc', ar: 'GFRC', en: 'GFRC', descAr: 'واجهات وعناصر معمارية خفيفة ومتينة، بلمسة ذهبية وتفاصيل تليق بواجهتك.', descEn: 'Lightweight, durable façades and architectural elements with refined golden detail.', icon: Landmark, img: mosqueImg },
    { key: 'gfrp', ar: 'GFRP', en: 'GFRP', descAr: 'عناصر مقوّاة بالألياف الزجاجية: خفيفة، مقاومة للعوامل الجوية، وسهلة التشكيل.', descEn: 'Glass-fibre reinforced plastic: light, weather-resistant and beautifully shaped.', icon: Layers, img: interiorImg },
    { key: 'gfrg', ar: 'GFRG', en: 'GFRG', descAr: 'ألواح وأسقف وديكورات جبسية مقوّاة بالألياف لدقة تشطيب أعلى وسرعة تنفيذ أكبر.', descEn: 'Fibre-reinforced gypsum panels, ceilings and décor for faster, cleaner finishing.', icon: Sparkles, img: majlisImg },
    { key: 'steel', ar: 'الهياكل الفولاذية', en: 'Steel Structure', descAr: 'مستودعات وقاعات وهياكل بتصميم إنشائي معتمد وتنفيذ آمن يليق بمشروعك.', descEn: 'Warehouses, halls and structures with certified engineering and safe execution.', icon: Factory, img: steelImg },
    { key: 'container', ar: 'تعديل الحاويات', en: 'Container Modification', descAr: 'حاويات تتحول إلى مكاتب وكافيهات وعيادات ومساحات تجارية بهوية خاصة بك.', descEn: 'Containers transformed into offices, cafés, clinics and retail spaces with your identity.', icon: Container, img: containerImg },
    { key: 'contracting', ar: 'المقاولات العامة', en: 'Building Contracting', descAr: 'تنفيذ متكامل من التأسيس حتى التسليم، بإدارة موقع واحدة وجدول زمني واضح.', descEn: 'Full turnkey execution from foundation to handover, under one accountable team.', icon: Building2, img: factoryImg },
    { key: 'transport', ar: 'النقل والتركيب', en: 'Transportation', descAr: 'نقل وتوريد وتركيب الوحدات الجاهزة والهياكل داخل السعودية بأمان كامل.', descEn: 'Safe delivery and installation of prefab units and structures across Saudi Arabia.', icon: Truck, img: villaImg },
  ];

  const projects = [
    { img: villaImg, title: ar ? 'فيلا فاخرة — القصيم' : 'Luxury Villa — Al-Qassim', meta: ar ? 'واجهة GFRC • تشطيب ذهبي' : 'GFRC façade • Golden finish', tag: ar ? 'مبانٍ جاهزة' : 'Prefab Houses' },
    { img: interiorImg, title: ar ? 'قاعة استقبال ملكية' : 'Royal Reception Hall', meta: ar ? 'أعمدة GFRG • ثريا ذهبية' : 'GFRG columns • Golden chandelier', tag: 'GFRG' },
    { img: factoryImg, title: ar ? 'مصنع GFRC — حرفية دقيقة' : 'GFRC Factory — Precise Craft', meta: ar ? 'قوالب مخصصة • جودة مضبوطة' : 'Custom moulds • Controlled quality', tag: 'GFRC' },
    { img: majlisImg, title: ar ? 'مجلس فاخر — إضاءة ذهبية' : 'Luxury Majlis — Golden Light', meta: ar ? 'واجهات مشغولة • حضور راقٍ' : 'Ornamental façades • Refined presence', tag: ar ? 'مجلس' : 'Majlis' },
    { img: containerImg, title: ar ? 'مكتب حاويات — هوية خاصة' : 'Container Office — Your Identity', meta: ar ? 'مكتب أعمال • تشطيب ذهبي' : 'Business office • Golden finish', tag: ar ? 'حاويات' : 'Container' },
    { img: steelImg, title: ar ? 'فيلا بهيكل فولاذي' : 'Steel Villa — Built to Last', meta: ar ? 'هيكل فولاذي • تنفيذ آمن' : 'Steel frame • Safe execution', tag: ar ? 'فولاذ' : 'Steel' },
  ];

  const faqs = [
    { q: ar ? 'ماذا تفعل شركة الكادر المحترف؟' : 'What does Alkader Almohtarif do?', a: ar ? 'نصمّم ونصنّع ونركّب المباني الجاهزة وواجهات GFRC والهياكل الفولاذية، وننفذ مشاريع المقاولات والتشطيب من الفكرة حتى التسليم.' : 'We design, manufacture and install prefab buildings, GFRC façades and steel structures, and deliver contracting and fit-out projects from concept to handover.' },
    { q: ar ? 'هل أنتم مصنّع مبانٍ جاهزة؟' : 'Are you a prefab manufacturer?', a: ar ? 'نعم. نمتلك مصنعنا الخاص، ونصنّع الوحدات داخل المصنع بجودة مضبوطة، ثم نركّبها في الموقع بسرعة ودقة.' : 'Yes. We own our factory and manufacture units in-house under controlled quality, then install them on site quickly and precisely.' },
    { q: ar ? 'هل تصنّعون GFRC؟' : 'Do you manufacture GFRC?', a: ar ? 'نعم. نصنّع واجهات وعناصر GFRC المعمارية داخل مصنعنا، بتشطيبات خفيفة ومتينة وحضور فاخر يدوم.' : 'Yes. We manufacture GFRC façades and architectural elements in-house — lightweight, durable and elegantly finished.' },
    { q: ar ? 'أين فرعكم؟ وفي أي مناطق تعملون؟' : 'Where is your branch, and which areas do you serve?', a: ar ? 'لدينا فرع واحد فقط: مقرنا الرئيسي في الرس، القصيم، السعودية. ونخدم الرياض وجدة والدمام ومكة والمدينة وجميع مناطق السعودية، ودول الخليج عند الطلب.' : 'We have one branch only: our headquarters in Al-Rass, Al-Qassim, Saudi Arabia. We serve Riyadh, Jeddah, Dammam, Makkah, Madinah and all Saudi regions, and GCC projects on request.' },
    { q: ar ? 'كيف أحصل على عرض سعر؟' : 'How can I get a quotation?', a: ar ? 'أرسل النموذج بالأسفل، أو راسلنا على واتساب. سنراجع متطلباتك ونرسل لك عرضاً واضحاً بالمواصفات والجدول الزمني. تبدأ الميزانيات من 100,000 ريال.' : 'Send the form below or message us on WhatsApp. We will review your requirements and send a clear offer with specifications and timeline. Budgets start from SAR 100,000.' },
  ];

  useEffect(() => {
    if (paused) return;
    const id = window.setInterval(() => setSlide(s => (s + 1) % slides.length), 4000);
    return () => window.clearInterval(id);
  }, [paused, slides.length]);

  useEffect(() => {
    let alive = true;
    (async () => {
      try { const d: any = await api('records.list', { collection: 'inquiries' }); if (alive) setSavedCount((d?.records || []).length); }
      catch { if (alive) setLoadError(ar ? 'تعذّر تحميل عدد الطلبات الآن.' : 'Request count is unavailable right now.'); }
    })();
    return () => { alive = false; };
  }, [ar]);

  async function submitForm(e: React.FormEvent) {
    e.preventDefault(); if (busy) return;
    const row = { service, area, city, budget, name: name.trim(), phone: phone.trim(), message: message.trim(), lang, source: 'website-v4-final' };
    setBusy(true); let saved = 0; let error: string | null = null;
    try { await api('records.create', { collection: 'inquiries', value: row, idempotency_key: `inq-v4-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` }); saved = 1; }
    catch (err) { error = err instanceof Error ? err.message : String(err); }
    let reloadError: string | null = null;
    try { const d: any = await api('records.list', { collection: 'inquiries' }); setSavedCount((d?.records || []).length); }
    catch (err) { reloadError = err instanceof Error ? err.message : String(err); }
    setResult({ saved, remaining: error ? 1 : 0, error, reloadError }); setBusy(false);
    if (!error) { setName(''); setPhone(''); setMessage(''); }
  }

  const cityOptions = ar
    ? ['الرس', 'القصيم', 'الرياض', 'جدة', 'الدمام', 'مكة', 'المدينة', 'أخرى — دول الخليج عند الطلب']
    : ['Al-Rass', 'Al-Qassim', 'Riyadh', 'Jeddah', 'Dammam', 'Makkah', 'Madinah', 'Other — GCC on request'];
  const inputCls = 'w-full h-[52px] bg-white border border-[#E8D9A8] rounded-[12px] px-4 text-[15px] outline-none focus:border-[#C9A227] focus:ring-2 focus:ring-[#C9A227]/20';
  const labelCls = 'block text-sm font-bold mb-2';
  const ArrowPrev = ar ? ChevronRight : ChevronLeft;
  const ArrowNext = ar ? ChevronLeft : ChevronRight;

  return (
    <div data-safe-area-inset-root dir={ar ? 'rtl' : 'ltr'} lang={ar ? 'ar' : 'en'} style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', minHeight: '100vh', background: '#FFFFFF', color: '#1A1A1A' }} className="overflow-x-clip">
      {/* TOP GOLD BAR */}
      <div className="gold-bg text-[#1A1A1A]">
        <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-center sm:justify-between gap-x-4 gap-y-1 text-[12px] sm:text-[13px] font-bold">
          <span className="flex items-center gap-1.5"><MapPin size={14} className="text-[#0F3D2E]" />{ar ? 'فرع واحد — القصيم، الرس | السعودية' : 'One Branch — Al-Qassim, Al-Rass | Saudi Arabia'}</span>
          <span className="hidden md:flex items-center gap-1.5"><Clock size={14} />{ar ? 'السبت - الخميس: 8ص - 6م' : 'Sat - Thu: 8AM - 6PM'}</span>
          <span className="flex items-center gap-3 flex-wrap justify-center">
            <a href="tel:+966503340303" dir="ltr" className="flex items-center gap-1 hover:underline"><Phone size={13} />+966 5033 40303</a>
            <span className="opacity-50">|</span>
            <a href="tel:+966505420303" dir="ltr" className="flex items-center gap-1 hover:underline"><Phone size={13} />+966 5054 20303</a>
            <span className="hidden sm:inline opacity-50">|</span>
            <span className="font-en tracking-wide">alkader_sa</span>
          </span>
        </div>
      </div>

      {/* HEADER */}
      <header data-safe-area-sticky-top className="sticky z-40 bg-white/95 backdrop-blur border-b border-[#E8D9A8]" style={{ top: 'var(--safe-area-inset-top)' }}>
        <div className="max-w-7xl mx-auto px-4 h-[74px] flex items-center justify-between gap-3">
          <a href="#home" className="flex items-center gap-3 min-w-0">
            <span className="w-11 h-11 shrink-0 rounded-xl gold-bg grid place-items-center text-white shadow-md"><Crown size={24} /></span>
            <span className="leading-none min-w-0"><span className="block text-[19px] sm:text-[21px] font-black truncate">{ar ? 'الكادر المحترف' : 'Alkader Almohtarif'}</span><span className="block font-lux text-[10px] tracking-[.22em] text-[#8A8578] mt-1">{ar ? 'الرس • القصيم' : 'AL-RASS • AL-QASSIM'}</span></span>
          </a>
          <nav className="hidden lg:flex items-center gap-7 font-bold text-[14px]">
            <a href="#home" className="hover:text-[#B9975B]">{t.home}</a><a href="#services" className="hover:text-[#B9975B]">{t.services}</a><a href="#projects" className="hover:text-[#B9975B]">{t.projects}</a><a href="#about" className="hover:text-[#B9975B]">{t.about}</a><a href="#contact" className="hover:text-[#B9975B]">{t.contact}</a>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setLang(ar ? 'en' : 'ar')} className="border border-[#E8D9A8] rounded-full px-3 py-2 font-extrabold text-sm flex items-center gap-1.5 hover:border-[#C9A227] bg-white" aria-label="Switch language"><Globe size={15} className="text-[#B9975B]" /><span className={ar ? '' : 'text-[#B9975B]'}>EN</span><span className="text-[#D8C99A]">|</span><span className={ar ? 'text-[#B9975B]' : ''}>AR</span></button>
            <a href="#contact" className="hidden sm:inline-flex gold-bg text-white rounded-full px-5 py-2.5 font-extrabold text-sm shadow-md">{t.quote}</a>
            <button onClick={() => setMenu(v => !v)} aria-label="menu" className="lg:hidden border border-[#E8D9A8] rounded-full p-2.5">{menu ? <X size={19} /> : <Menu size={19} />}</button>
          </div>
        </div>
        {menu && <nav className="lg:hidden border-t border-[#E8D9A8] px-4 py-3 grid gap-1 font-bold bg-white">{[[t.home, '#home'], [t.services, '#services'], [t.projects, '#projects'], [t.about, '#about'], [t.contact, '#contact']].map(([label, href]) => <a key={href} href={href} onClick={() => setMenu(false)} className="py-2.5 px-3 rounded-xl hover:bg-[#FDFBF6]">{label}</a>)}</nav>}
      </header>

      {/* HERO SLIDER — 7 IMAGES, CROSSFADE 1.2s + KEN BURNS */}
      <section id="home" className="relative overflow-x-clip bg-white">
        <div className="relative min-h-[88vh] sm:min-h-[92vh]">
          {slides.map((s, i) => (
            <div key={s.title} aria-hidden={i !== slide} className="absolute inset-0 transition-opacity duration-[1200ms] ease-in-out" style={{ opacity: i === slide ? 1 : 0, zIndex: i === slide ? 1 : 0 }}>
              <img src={s.img} alt={s.title} className={`absolute inset-0 w-full h-full object-cover ${i === slide ? 'ken-burns' : ''}`} />
            </div>
          ))}
          <div className="absolute inset-0 z-[2] bg-gradient-to-t from-[#FDFBF6] via-[#FDFBF6]/45 to-[#FDFBF6]/10" />
          <div className="absolute inset-0 z-[2] bg-gradient-to-r from-[#FDFBF6]/80 via-[#FDFBF6]/20 to-transparent" />
          <div className="relative z-[3] max-w-7xl mx-auto px-4 pt-12 sm:pt-16 pb-44 flex items-center min-h-[88vh] sm:min-h-[92vh]">
            <div className="max-w-3xl">
              <span className="inline-flex items-center gap-2 bg-white/90 backdrop-blur border border-[#E8D9A8] rounded-full px-4 py-2 text-[12px] font-extrabold text-[#0F3D2E] shadow-sm"><Sparkles size={14} className="text-[#C9A227]" />{t.heroBadge}</span>
              <h1 className="mt-6 font-black leading-[1.08] text-[clamp(38px,6.8vw,74px)]">{t.heroTitle1}<br /><span className="gold-text">{t.heroTitle2}</span></h1>
              <p className="mt-4 text-base sm:text-lg text-[#4A463C] leading-relaxed max-w-2xl font-semibold">{t.heroSub}</p>
              <div key={slide} className="fade-up mt-5 inline-flex items-center gap-2 bg-white/90 border border-[#E8D9A8] rounded-full px-4 py-2 text-sm font-extrabold text-[#0F3D2E] shadow-sm">
                <span className="gold-bg text-white rounded-full px-2.5 py-0.5 text-xs">{slides[slide].tag}</span>
                {slides[slide].title} <span className="hidden sm:inline text-[#8A8578] font-semibold">— {slides[slide].sub}</span>
              </div>
              <div className="mt-7 flex flex-wrap gap-3">
                <a href="#contact" className="gold-bg text-white rounded-full px-7 py-4 font-extrabold flex items-center gap-2 shadow-lg shadow-[#C9A227]/30">{t.quote} {React.createElement(dirArrow, { size: 18 })}</a>
                <a href="#projects" className="bg-white text-[#1A1A1A] border border-[#E8D9A8] rounded-full px-7 py-4 font-extrabold shadow-md">{t.explore}</a>
              </div>
            </div>
          </div>
          {/* SLIDER CONTROLS */}
          <div className="absolute bottom-5 start-0 end-0 z-[4] px-4">
            <div className="max-w-5xl mx-auto">
              <div className="flex items-center justify-between gap-3">
                <button onClick={() => setSlide((slide - 1 + slides.length) % slides.length)} aria-label={ar ? 'السابق' : 'Previous slide'} className="w-11 h-11 rounded-full bg-white/95 border border-[#E8D9A8] shadow-lg grid place-items-center hover:border-[#C9A227]"><ArrowPrev size={19} /></button>
                <div className="flex items-center gap-2 flex-wrap justify-center">
                  {slides.map((s, i) => (
                    <button key={s.title} onClick={() => setSlide(i)} aria-label={`${ar ? 'شريحة' : 'Slide'} ${i + 1}`} className={`rounded-full transition-all ${i === slide ? 'w-10 h-2.5 bg-[#C9A227]' : 'w-2.5 h-2.5 bg-white/80 border border-[#E8D9A8] hover:bg-[#E8D9A8]'}`} />
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setPaused(v => !v)} aria-label={paused ? (ar ? 'تشغيل' : 'Play') : (ar ? 'إيقاف' : 'Pause')} className="w-11 h-11 rounded-full bg-white/95 border border-[#E8D9A8] shadow-lg grid place-items-center hover:border-[#C9A227]">{paused ? <Play size={18} /> : <Pause size={18} />}</button>
                  <button onClick={() => setSlide((slide + 1) % slides.length)} aria-label={ar ? 'التالي' : 'Next slide'} className="w-11 h-11 rounded-full bg-white/95 border border-[#E8D9A8] shadow-lg grid place-items-center hover:border-[#C9A227]"><ArrowNext size={19} /></button>
                </div>
              </div>
              {!paused && <div className="mt-3 h-1 bg-white/70 rounded-full overflow-hidden"><div key={slide} className="h-full gold-bg slide-progress" /></div>}
              <p className="mt-2 text-center text-xs font-bold text-[#5E5A50]">{slide + 1} / {slides.length} — {slides[slide].title}</p>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="bg-white border-b border-[#E8D9A8]">
        <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {t.stats.map(s => (
            <div key={s.l} className="rounded-2xl border border-[#E8D9A8] bg-[#FDFBF6] px-4 py-5 text-center">
              <div className="font-black text-[clamp(24px,4vw,36px)] gold-text">{s.v}</div>
              <div className="text-[13px] sm:text-sm font-bold text-[#5E5A50] mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES — 8 UNIFIED CARDS */}
      <section id="services" className="bg-[#FDFBF6] py-14 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <p className="eyebrow text-[#B9975B] text-center">{ar ? 'خدماتنا' : 'OUR SERVICES'}</p>
          <h2 className="text-3xl sm:text-[44px] font-black text-center mt-3 leading-tight">{ar ? 'كل ما يحتاجه مشروعك، بذوقٍ ملكي' : 'Everything Your Project Needs, With Royal Taste'}</h2>
          <p className="text-center font-lux text-lg text-[#8A8578] mt-2">{ar ? 'كل ما يحتاجه مشروعك' : 'Everything Your Project Needs'}</p>
          <div className="mt-6"><Ornament /></div>
          <div className="mt-9 grid sm:grid-cols-2 lg:grid-cols-4 gap-5 items-stretch">
            {services.map(s => {
              const Icon = s.icon;
              const active = service === s.key;
              return (
                <article key={s.key} className="card-hover rounded-[24px] overflow-hidden border border-[#E8D9A8] bg-white flex flex-col h-full">
                  <div className="relative h-48 shrink-0 overflow-hidden bg-cover bg-center" role="img" aria-label={ar ? s.ar : s.en} style={{ backgroundImage: `url(${s.img})` }}>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/25 to-transparent" />
                    <span className="absolute bottom-3 start-3 w-12 h-12 rounded-xl bg-white border border-[#E8D9A8] grid place-items-center text-[#B9975B] shadow-md"><Icon size={24} /></span>
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <h3 className="font-black text-xl leading-snug min-h-[28px]">{ar ? s.ar : s.en}</h3>
                    <p className="text-sm text-[#5E5A50] leading-relaxed mt-2 flex-1">{ar ? s.descAr : s.descEn}</p>
                    <button onClick={() => { setService(s.key); document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }); }} className="mt-4 self-start text-[#0F3D2E] font-extrabold text-sm flex items-center gap-1.5 hover:text-[#B9975B]">{active ? (ar ? '✓ تم اختيار الخدمة' : '✓ Service Selected') : (ar ? 'اطلب هذه الخدمة' : 'Request this service')} {React.createElement(dirArrow, { size: 16 })}</button>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* PROJECTS — 6 UNIFIED CARDS, 4:3 */}
      <section id="projects" className="bg-white py-14 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <p className="eyebrow text-[#B9975B] text-center">{ar ? 'أعمالنا' : 'OUR WORK'}</p>
          <h2 className="text-3xl sm:text-[44px] font-black text-center mt-3">{ar ? 'أعمالنا تتكلم' : 'Our Work Speaks'}</h2>
          <p className="text-center font-lux text-lg text-[#8A8578] mt-2">{ar ? 'أعمالنا تتكلم قبل أن نتكلم' : 'Our Work Speaks Before We Do'}</p>
          <div className="mt-6"><Ornament /></div>
          <div className="mt-9 grid sm:grid-cols-2 lg:grid-cols-3 gap-5 items-stretch">
            {projects.map(p => (
              <article key={p.title} className="card-hover group relative rounded-[24px] overflow-hidden border border-[#E8D9A8] bg-white flex flex-col h-full">
                <div className="relative aspect-[4/3] overflow-hidden shrink-0 bg-cover bg-center transition duration-700 group-hover:scale-105" role="img" aria-label={p.title} style={{ backgroundImage: `url(${p.img})` }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                  <span className="absolute top-3 start-3 bg-white text-[#1A1A1A] rounded-full px-3 py-1 text-xs font-extrabold shadow">{p.tag}</span>
                  <div className="absolute bottom-0 start-0 end-0 p-5 text-white">
                    <h3 className="font-black text-xl leading-snug">{p.title}</h3>
                    <p className="text-white/85 text-sm mt-1">{p.meta}</p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT — SOLID IVORY */}
      <section id="about" className="bg-[#FDFBF6] border-y border-[#E8D9A8] py-14 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-10 items-center">
          <div className="relative">
            <div className="absolute -top-3 -start-3 w-full h-full rounded-[30px] border border-[#C9A227]/50" aria-hidden="true" />
            <div className="relative rounded-[30px] overflow-hidden border border-[#E8D9A8] shadow-xl">
              <div className="w-full h-[360px] sm:h-[480px] bg-cover bg-center" role="img" aria-label={ar ? 'واجهة فاخرة بتفاصيل GFRC ذهبية' : 'Luxury façade with golden GFRC detail'} style={{ backgroundImage: `url(${mosqueImg})` }} />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-6 text-white">
                <p className="font-black text-xl">{ar ? 'حرفة تُرى في كل تفصيلة' : 'Craft You Can See in Every Detail'}</p>
                <p className="text-white/85 text-sm mt-1">{ar ? 'من القالب الأول حتى اللمسة الأخيرة' : 'From the first mould to the final touch'}</p>
              </div>
            </div>
            <div className="absolute -bottom-5 start-5 bg-white rounded-2xl border border-[#E8D9A8] shadow-xl px-5 py-4 flex items-center gap-3"><span className="w-11 h-11 rounded-xl bg-[#0F3D2E] text-white grid place-items-center"><BadgeCheck size={24} /></span><div><div className="font-black">{ar ? 'مصنعنا الخاص' : 'Our Own Factory'}</div><div className="text-sm text-[#5E5A50]">{ar ? 'جودة مضبوطة من القالب حتى التركيب' : 'Controlled quality, mould to installation'}</div></div></div>
          </div>
          <div>
            <p className="eyebrow text-[#B9975B]">{ar ? 'من نحن' : 'ABOUT US'}</p>
            <h2 className="text-3xl sm:text-[42px] font-black leading-[1.25] mt-3">{ar ? 'حرفة المصنع.. وذوق القصور' : 'Factory Craft, Palace Taste'}</h2>
            <p className="font-lux text-lg text-[#8A8578] mt-2">{ar ? 'حرفة تُرى في كل تفصيلة' : 'Craftsmanship You Can See in Every Detail'}</p>
            <p className="text-[#5E5A50] leading-relaxed mt-5">{ar ? 'في الكادر المحترف، لا ننظر إلى البناء كخرسانة وحديد فقط، بل كحرفة تُصنع بعناية وتُسلَّم كتحفة. من فرعنا الواحد في الرس، القصيم، نخدم جميع مناطق السعودية بفريق واحد: تصميم، تصنيع، تركيب، وتسليم.' : 'At Alkader Almohtarif, building is not only concrete and steel — it is a craft made with care and delivered as a masterpiece. From our one branch in Al-Rass, Al-Qassim, we serve all of Saudi Arabia with one team: design, manufacturing, installation and handover.'}</p>
            <ul className="mt-6 grid gap-3">
              {[ar ? 'قوالب وتفاصيل معمارية مخصصة حول ذوقك' : 'Custom moulds and architectural details around your taste', ar ? 'تشطيبات ذهبية نظيفة تدوم مع الزمن' : 'Clean golden finishes that last', ar ? 'جداول واضحة ومسؤولية واحدة حتى التسليم' : 'Clear schedules and one accountable owner to handover', ar ? 'فريق هندسي يتابع مشروعك لحظة بلحظة' : 'An engineering team following your project step by step'].map(x => <li key={x} className="flex gap-2.5 items-start font-bold"><CheckCircle2 className="text-[#C9A227] shrink-0 mt-0.5" size={21} />{x}</li>)}
            </ul>
            <div className="grid grid-cols-3 gap-3 mt-8 text-center">
              {[['+10', ar ? 'سنوات' : 'Years'], ['95%', ar ? 'في الوقت' : 'On Time'], ['3X', ar ? 'أسرع' : 'Faster']].map(([v, l]) => (
                <div key={l} className="bg-white border border-[#E8D9A8] rounded-2xl py-4 px-2"><div className="font-black text-2xl gold-text">{v}</div><div className="text-xs font-bold text-[#5E5A50] mt-1">{l}</div></div>
              ))}
            </div>
            <a href="#contact" className="inline-flex mt-7 gold-bg text-white rounded-full px-7 py-3.5 font-extrabold shadow-lg shadow-[#C9A227]/25">{ar ? 'ابدأ مشروعك معنا' : 'Start Your Project With Us'}</a>
          </div>
        </div>
      </section>

      {/* WHY US — 4 UNIFIED CARDS */}
      <section className="bg-white py-14 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <p className="eyebrow text-[#B9975B] text-center">{ar ? 'لماذا نحن' : 'WHY CHOOSE US'}</p>
          <h2 className="text-3xl sm:text-[42px] font-black text-center mt-3">{ar ? 'الفرق ليس في ما نبنيه، بل في كيف نبنيه' : 'The Difference Is How We Build It'}</h2>
          <p className="text-center font-lux text-lg text-[#8A8578] mt-2">{ar ? 'الفرق ليس في ما نبنيه، بل في كيف نبنيه' : 'The Difference Isn’t What We Build. It’s How We Build It.'}</p>
          <div className="mt-6"><Ornament /></div>
          <div className="mt-9 grid sm:grid-cols-2 lg:grid-cols-4 gap-5 items-stretch">
            {[[Layers, ar ? '95% في الوقت' : '95% On-Time', ar ? 'جداول واقعية والتزام نتابعه معك.' : 'Realistic schedules and commitments you can track.'], [HardHat, ar ? '3X أسرع' : '3X Faster', ar ? 'تصنيع متوازٍ مع تجهيز الموقع.' : 'Parallel manufacturing and site prep.'], [Factory, ar ? 'مصنعنا الخاص' : 'In-House Factory', ar ? 'تحكم كامل في الجودة والوقت.' : 'Full control over quality and time.'], [Ruler, ar ? 'مصمّم خصيصاً لك' : 'Custom-Built', ar ? 'كل مشروع حول احتياجك وميزانيتك.' : 'Every project around your need and budget.']].map(([Icon, title, desc]: any) => (
              <div key={title} className="card-hover rounded-[24px] border border-[#E8D9A8] bg-white p-6 text-center flex flex-col h-full">
                <div className="mx-auto w-14 h-14 rounded-2xl gold-bg grid place-items-center text-white shadow-md"><Icon size={26} /></div>
                <h3 className="font-black text-xl mt-4 leading-snug min-h-[28px]">{title}</h3><p className="text-sm text-[#5E5A50] leading-relaxed mt-2 flex-1">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COVERAGE — ONE BRANCH */}
      <section className="bg-[#FDFBF6] border-y border-[#E8D9A8] py-14 sm:py-16">
        <div className="max-w-7xl mx-auto px-4">
          <p className="eyebrow text-[#B9975B] text-center">{ar ? 'تغطيتنا' : 'COVERAGE'}</p>
          <h2 className="text-3xl sm:text-4xl font-black text-center mt-3">{ar ? 'من الرس في القصيم إلى كل السعودية' : 'From Al-Rass, Al-Qassim — To All Saudi Arabia'}</h2>
          <p className="text-center font-lux text-lg text-[#8A8578] mt-2">{ar ? 'فرع واحد • مقر رئيسي واحد' : 'One Branch • One Headquarters'}</p>
          <div className="mt-8 grid md:grid-cols-2 gap-5 items-stretch">
            <div className="rounded-[24px] border border-[#E8D9A8] bg-white p-6 flex flex-col">
              <div className="flex items-center gap-2"><span className="w-11 h-11 rounded-xl bg-[#0F3D2E] text-white grid place-items-center"><MapPin size={21} /></span><h3 className="font-black text-xl">{ar ? 'مقرنا الرئيسي — الفرع الوحيد' : 'Our Headquarters — The Only Branch'}</h3></div>
              <p className="text-[#5E5A50] leading-relaxed mt-4 flex-1">{ar ? 'الرس، القصيم، المملكة العربية السعودية. فريق واحد ومصنع واحد وإدارة واحدة — حتى يبقى مشروعك تحت مسؤولية واضحة من أول رسمة حتى التسليم.' : 'Al-Rass, Al-Qassim, Saudi Arabia. One team, one factory and one management — so your project stays under clear ownership from first sketch to handover.'}</p>
              <div className="mt-4 flex flex-wrap gap-2"><span className="gold-bg text-white rounded-full px-4 py-2 text-sm font-extrabold">{ar ? 'فرع واحد فقط' : 'One Branch Only'}</span><span className="bg-[#FDFBF6] border border-[#E8D9A8] rounded-full px-4 py-2 text-sm font-bold">{ar ? 'الرس • القصيم' : 'Al-Rass • Al-Qassim'}</span></div>
            </div>
            <div className="rounded-[24px] border border-[#E8D9A8] bg-white p-6">
              <div className="flex items-center gap-2"><span className="w-11 h-11 rounded-xl gold-bg text-white grid place-items-center"><Building2 size={21} /></span><h3 className="font-black text-xl">{ar ? 'نخدم جميع مناطق السعودية' : 'We Serve All Saudi Arabia'}</h3></div>
              <div className="mt-4 flex flex-wrap gap-2">{ar ? ['الرياض', 'جدة', 'الدمام', 'مكة', 'المدينة', 'القصيم', 'تبوك', 'أبها'] : ['Riyadh', 'Jeddah', 'Dammam', 'Makkah', 'Madinah', 'Al-Qassim', 'Tabuk', 'Abha'].map(x => <span key={x} className="bg-[#FDFBF6] border border-[#E8D9A8] rounded-full px-4 py-2 text-sm font-bold">{x}</span>)}</div>
              <p className="text-sm text-[#8A8578] mt-4 font-bold">{ar ? 'ودول الخليج عند الطلب.' : 'And GCC projects on request.'}</p>
            </div>
          </div>
          <h3 className="font-black text-xl text-center mt-12">{ar ? 'شركاء نجاح نعتز بهم' : 'Partners We Are Proud Of'}</h3>
          <div className="mt-5 flex flex-wrap justify-center gap-3">{[ar ? 'وزارة البلديات والإسكان' : 'Ministry of Municipalities & Housing', ar ? 'وزارة التعليم' : 'Ministry of Education', 'BMC', 'MASAH', ar ? 'الفؤاد' : 'Alfouad'].map(p => <span key={p} className="bg-white border border-[#E8D9A8] rounded-full px-5 py-3 font-extrabold shadow-sm flex items-center gap-2"><Star size={15} className="text-[#C9A227]" />{p}</span>)}</div>
        </div>
      </section>

      {/* SMART INQUIRY — UNIFIED INPUTS */}
      <section id="contact" className="bg-white py-14 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid lg:grid-cols-[.9fr_1.1fr] gap-6 items-stretch">
            <div className="rounded-[30px] border border-[#E8D9A8] bg-[#FDFBF6] p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <span className="inline-flex items-center gap-2 gold-bg text-white rounded-full px-4 py-1.5 text-xs font-extrabold"><ShieldCheck size={14} />{ar ? 'طلب ذكي' : 'SMART INQUIRY'}</span>
                <h2 className="text-3xl sm:text-4xl font-black mt-4 leading-snug">{ar ? 'أرسل طلبك.. ودع الفخامة تبدأ' : 'Send Your Request, Let Luxury Begin'}</h2>
                <p className="font-lux text-lg text-[#8A8578] mt-2">{ar ? 'أرسل طلبك — ودع الفخامة تبدأ' : 'Send Your Request — Let Luxury Begin'}</p>
                <p className="text-[#5E5A50] leading-relaxed mt-4">{ar ? 'اختر خدمتك، حدّد مساحتك ومدينتك وميزانيتك، وسيتواصل معك مهندس مختص بعرض واضح.' : 'Choose your service, set your area, city and budget, and a specialist engineer will contact you with a clear offer.'}</p>
                <div className="mt-6 grid gap-3 text-sm font-bold">{[ar ? 'رد سريع عبر واتساب' : 'Fast reply on WhatsApp', ar ? 'عرض واضح بالمواصفات والجدول' : 'Clear offer with specs and timeline', ar ? 'متابعة هندسية حتى التسليم' : 'Engineering follow-up to handover'].map(x => <p key={x} className="flex gap-2 bg-white border border-[#E8D9A8] rounded-[12px] px-4 py-3"><CheckCircle2 size={18} className="text-[#C9A227] shrink-0" />{x}</p>)}</div>
              </div>
              <div className="mt-7 bg-white border border-[#E8D9A8] rounded-[12px] px-4 py-3 flex items-center justify-between text-sm"><span className="font-bold text-[#5E5A50]">{ar ? 'الطلبات المحفوظة:' : 'Saved requests:'}</span><b className="text-[#B9975B] text-lg">{savedCount ?? '—'}</b></div>
              {loadError && <p className="text-xs text-amber-700 mt-2">{loadError}</p>}
            </div>
            <form onSubmit={submitForm} className="bg-white rounded-[30px] border-2 border-[#E8D9A8] p-5 sm:p-7 shadow-xl shadow-[#C9A227]/10">
              <h2 className="font-black text-2xl">{ar ? 'نموذج الطلب الذكي' : 'Smart Inquiry Form'}</h2><p className="text-sm text-[#5E5A50] mt-1">{ar ? 'أرسل طلبك وسيتواصل معك مهندس مختص.' : 'Send your request and a specialist engineer will contact you.'}</p>
              <div className="grid sm:grid-cols-2 gap-4 mt-5">
                <label className="block"><span className={labelCls}>{ar ? 'نوع الخدمة *' : 'Service Type *'}</span><select value={service} onChange={e => setService(e.target.value as ServiceKey)} className={inputCls}>{services.map(s => <option key={s.key} value={s.key}>{ar ? s.ar : s.en}</option>)}</select></label>
                <label className="block"><span className={labelCls}>{ar ? 'المدينة *' : 'City *'}</span><select value={city} onChange={e => setCity(e.target.value)} className={inputCls}>{cityOptions.map(c => <option key={c} value={c}>{c}</option>)}</select></label>
                <label className="block"><span className={labelCls}>{ar ? 'المساحة *' : 'Area *'}</span><div className="flex items-center gap-3 bg-white border border-[#E8D9A8] rounded-[12px] px-4 h-[52px]"><input type="range" min={40} max={2000} step={20} value={area} onChange={e => setArea(Number(e.target.value))} className="flex-1 accent-[#C9A227]" /><b className="text-[#B9975B] whitespace-nowrap">{area} {ar ? 'م²' : 'm²'}</b></div></label>
                <label className="block"><span className={labelCls}>{ar ? 'الاسم *' : 'Name *'}</span><input required value={name} onChange={e => setName(e.target.value)} placeholder={ar ? 'مثال: أحمد' : 'e.g. Ahmed'} className={inputCls} /></label>
                <label className="block sm:col-span-2"><span className={labelCls}>{ar ? 'رقم الهاتف *' : 'Phone *'}</span><input required dir="ltr" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+966 ..." className={inputCls} /></label>
                <div className="block sm:col-span-2">
                  <span className={labelCls}>{ar ? 'الميزانية *' : 'Budget *'}</span>
                  <div className="bg-white border border-[#E8D9A8] rounded-[12px] px-4 py-4">
                    <div className="flex items-center justify-between gap-3 flex-wrap"><span className="text-sm font-bold text-[#5E5A50]">{ar ? 'تبدأ الميزانية من 100,000 ريال' : 'Budget starts from SAR 100,000'}</span><b className="text-[#B9975B] text-lg" dir="ltr">{fmtSAR(budget)}</b></div>
                    <input type="range" min={100000} max={5000000} step={50000} value={budget} onChange={e => setBudget(Number(e.target.value))} className="w-full mt-3 accent-[#C9A227]" aria-label={ar ? 'الميزانية' : 'Budget'} />
                    <div className="flex justify-between text-xs font-bold text-[#8A8578] mt-1" dir="ltr"><span>SAR 100,000</span><span>SAR 5,000,000</span></div>
                  </div>
                </div>
                <label className="block sm:col-span-2"><span className={labelCls}>{ar ? 'رسالتك' : 'Message'}</span><textarea value={message} onChange={e => setMessage(e.target.value)} rows={3} placeholder={ar ? 'اكتب تفاصيل مشروعك...' : 'Tell us about your project...'} className="w-full bg-white border border-[#E8D9A8] rounded-[12px] px-4 py-3 resize-y text-[15px] outline-none focus:border-[#C9A227] focus:ring-2 focus:ring-[#C9A227]/20" /></label>
              </div>
              <button disabled={busy} className="mt-5 w-full h-[52px] gold-bg text-white rounded-[12px] font-extrabold disabled:opacity-60 shadow-lg shadow-[#C9A227]/25">{busy ? (ar ? 'جارٍ الحفظ...' : 'Saving...') : (ar ? 'أرسل طلبك' : 'Send Your Request')}</button>
              <a href="https://wa.me/966503340303" target="_blank" rel="noopener" className="mt-3 w-full h-[52px] border border-[#E8D9A8] rounded-[12px] font-extrabold flex items-center justify-center gap-2"><MessageCircle size={18} className="text-[#22c55e]" />{ar ? 'أو راسلنا على واتساب' : 'Or message us on WhatsApp'}</a>
              {result && <div className="mt-4 rounded-[12px] bg-[#FDFBF6] border border-[#E8D9A8] p-4 text-sm leading-relaxed">{result.error ? <><b className="text-red-700">{ar ? 'تعذّر حفظ الطلب:' : 'Could not save request:'}</b> {result.error}<div>{ar ? 'تم الحفظ:' : 'Saved:'} {result.saved} • {ar ? 'المتبقي:' : 'Remaining:'} {result.remaining}</div></> : <><b>✓ {ar ? 'تم حفظ طلبك بنجاح. سيتواصل معك فريقنا قريباً.' : 'Your request was saved successfully. Our team will contact you soon.'}</b><div>{ar ? 'تم الحفظ:' : 'Saved:'} {result.saved} • {ar ? 'المتبقي:' : 'Remaining:'} {result.remaining}</div></>}{result.reloadError && <div className="text-amber-700">{result.reloadError}</div>}</div>}
            </form>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="bg-[#FDFBF6] border-t border-[#E8D9A8] py-14">
        <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-[.85fr_1.15fr] gap-8">
          <div><p className="eyebrow text-[#B9975B]">{ar ? 'الأسئلة الشائعة' : 'FAQ'}</p><h2 className="text-3xl sm:text-4xl font-black mt-2 leading-snug">{ar ? 'أسئلة يطرحها عملاؤنا كثيراً' : 'Questions Our Customers Ask Often'}</h2><p className="font-lux text-lg text-[#8A8578] mt-2">{ar ? 'أسئلة يطرحها عملاؤنا كثيراً' : 'Questions Our Customers Ask Often'}</p><p className="text-[#5E5A50] mt-3 leading-relaxed">{ar ? 'لم تجد إجابتك؟ راسلنا على واتساب وسيتواصل معك مهندس مختص.' : 'Didn’t find your answer? Message us on WhatsApp and a specialist engineer will contact you.'}</p><a href="https://wa.me/966503340303" target="_blank" rel="noopener" className="inline-flex mt-5 bg-[#22c55e] text-white rounded-full px-6 py-3 font-extrabold items-center gap-2"><MessageCircle size={18} />{ar ? 'اسألنا على واتساب' : 'Ask us on WhatsApp'}</a></div>
          <div className="grid gap-3 content-start">{faqs.map((f, i) => <div key={f.q} className="rounded-2xl border border-[#E8D9A8] bg-white overflow-hidden"><button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between gap-3 text-start p-5 font-extrabold">{f.q}<ChevronDown size={20} className={`shrink-0 text-[#B9975B] transition-transform ${openFaq === i ? 'rotate-180' : ''}`} /></button>{openFaq === i && <p className="px-5 pb-5 text-[#5E5A50] leading-relaxed">{f.a}</p>}</div>)}</div>
        </div>
      </section>

      {/* FOOTER — SINGLE LOCATION */}
      <footer className="bg-white border-t-2 border-[#C9A227]">
        <div className="max-w-7xl mx-auto px-4 py-12 grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div><div className="flex items-center gap-2"><span className="w-10 h-10 gold-bg rounded-lg grid place-items-center text-white"><Crown size={21} /></span><b className="text-xl">{ar ? 'الكادر المحترف' : 'Alkader Almohtarif'}</b></div><p className="text-sm text-[#5E5A50] leading-relaxed mt-4">{ar ? 'حلول بناء حديثة تجمع بين التصنيع الذكي والهندسة الدقيقة والذوق الملكي، من فرعنا الواحد في الرس، القصيم.' : 'Modern building solutions combining smart manufacturing, precise engineering and royal taste — from our one branch in Al-Rass, Al-Qassim.'}</p><p className="mt-4 text-xs text-[#8A8578] font-en tracking-wider">ALKADER ALMOHTARIF EST. • WWW.ALKADERCO.COM</p></div>
          <div><h3 className="font-black">{ar ? 'روابط سريعة' : 'Quick Links'}</h3><div className="grid gap-2 mt-4 text-[#5E5A50]">{[[t.services, '#services'], [t.projects, '#projects'], [t.about, '#about'], [t.contact, '#contact']].map(([l, h]) => <a key={h} href={h} className="hover:text-[#B9975B] font-bold">{l}</a>)}</div></div>
          <div><h3 className="font-black">{ar ? 'تواصل معنا' : 'Contact'}</h3><div className="grid gap-3 mt-4 text-sm text-[#5E5A50] font-bold"><a href="tel:+966503340303" dir="ltr" className="text-start hover:text-[#B9975B]">+966 5033 40303</a><a href="tel:+966505420303" dir="ltr" className="text-start hover:text-[#B9975B]">+966 5054 20303</a><span>alkader_sa</span><a href="https://www.alkaderco.com" target="_blank" rel="noopener" className="text-[#0F3D2E] hover:underline">www.alkaderco.com</a></div></div>
          <div><h3 className="font-black">{ar ? 'موقعنا الوحيد' : 'Our Only Location'}</h3><div className="grid gap-3 mt-4"><div className="rounded-2xl border border-[#E8D9A8] bg-[#FDFBF6] p-4"><b className="flex gap-2 items-center"><MapPin size={16} className="text-[#B9975B]" />{ar ? 'السعودية — فرع واحد' : 'Saudi Arabia — One Branch'}</b><p className="text-sm text-[#5E5A50] mt-1">{ar ? 'الرس، القصيم — المقر الرئيسي' : 'Al-Rass, Al-Qassim — Headquarters'}</p></div><div className="rounded-2xl border border-[#E8D9A8] bg-[#FDFBF6] p-4"><b className="flex gap-2 items-center"><MapPin size={16} className="text-[#0F3D2E]" />{ar ? 'نخدم' : 'We Serve'}</b><p className="text-sm text-[#5E5A50] mt-1">{ar ? 'جميع مناطق السعودية • الخليج عند الطلب' : 'All Saudi regions • GCC on request'}</p></div></div></div>
        </div>
        <div className="border-t border-[#E8D9A8] py-4 text-center text-xs text-[#8A8578] px-4">© {new Date().getFullYear()} {ar ? 'الكادر المحترف — جميع الحقوق محفوظة' : 'Alkader Almohtarif — All rights reserved'} • {ar ? 'النسخة 4 — أبيض وذهبي' : 'Version 4 — White & Gold'}</div>
      </footer>

      {/* FLOATING WHATSAPP - BOTTOM LEFT ALWAYS */}
      <a href="https://wa.me/966503340303" target="_blank" rel="noopener" aria-label="WhatsApp - instant reply" style={{ left: '16px' }} className="fixed bottom-5 z-50 flex items-center gap-2">
        <span className="wa-pulse w-[60px] h-[60px] rounded-full bg-[#22c55e] text-white grid place-items-center shadow-xl"><MessageCircle size={30} /></span>
        <span className="hidden sm:flex bg-white border border-[#E8D9A8] shadow-lg rounded-full px-4 py-2.5 font-extrabold text-sm items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#22c55e]" />{ar ? 'واتساب - رد فوري' : 'WhatsApp - Instant Reply'}</span>
      </a>
      {/* FLOATING LANGUAGE - MOBILE */}
      <button onClick={() => setLang(ar ? 'en' : 'ar')} aria-label="Switch language" className="sm:hidden fixed bottom-6 right-4 z-50 bg-white border border-[#E8D9A8] shadow-lg rounded-full px-4 py-3 font-extrabold text-sm flex items-center gap-1.5"><Globe size={16} className="text-[#B9975B]" />{ar ? 'EN' : 'عربي'}</button>
    </div>
  );
}
